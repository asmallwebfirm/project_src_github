The Drew Paul Inc. Module
==========================

Congratulations! You're so far down the rabbit hole that you've untarred the
tarball of a fake module that's meant to be used as a way to test a real
Drupal module by the name of [Project Source: GitHub][].

Obviously, this module contains no working code. No easter eggs, I'm afraid.
Just this link to search Google Images for "[rabbit hole][]."

[project source: github]: https://drupal.org/project/project_src_github
[rabbit hole]: https://www.google.com/search?q=rabbit+hole&tbm=isch
